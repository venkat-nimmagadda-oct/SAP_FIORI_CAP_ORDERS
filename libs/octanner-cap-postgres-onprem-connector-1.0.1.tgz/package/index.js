/**
 * @octanner/cap-postgres-onprem-connector
 * ========================================
 * Reusable connector for CAP projects to access on-prem PostgreSQL
 * through SAP Connectivity Service (SOCKS5 + JWT, method 0x80).
 *
 * Usage in any CAP project:
 * --------------------------
 *
 *   // server.js
 *   const cds = require('@sap/cds');
 *   const onPremPG = require('@octanner/cap-postgres-onprem-connector');
 *
 *   if (process.env.NODE_ENV === 'production') {
 *       onPremPG.patchCAP({
 *           cloudConnectorLocationId: 'OCT-SLC'
 *       });
 *   }
 *
 *   module.exports = cds.server;
 *
 * That's it. No custom SOCKS5/JWT code needed in the CAP project.
 */

const { patchCAP, unpatchCAP } = require('./lib/cap-patcher');
const { getConnectivityToken } = require('./lib/token-manager');
const { createTunnel } = require('./lib/tunnel-manager');
const { loadConnectivityBinding } = require('./lib/config-loader');

module.exports = {
    // Main entry point — call this in server.js
    patchCAP,
    
    // Advanced: unpatch (for testing)
    unpatchCAP,
    
    // Advanced: manual tunnel creation
    createTunnel,
    
    // Advanced: manual token retrieval
    getConnectivityToken,
    
    // Advanced: load connectivity binding directly
    loadConnectivityBinding
};