# @octanner/cap-postgres-onprem-connector

Reusable Node.js library that lets any **SAP CAP** project access **on-prem PostgreSQL** through SAP BTP **Connectivity Service** using the custom SOCKS5 method (`0x80`) and JWT authentication.

## Why?

CAP's default `@cap-js/postgres` adapter doesn't know how to:
- Use SAP custom SOCKS5 auth method (0x80)
- Retrieve JWT tokens from Connectivity Service
- Route through Cloud Connector via Location ID

This package handles all of that automatically.

## Installation

```bash
npm install @octanner/cap-postgres-onprem-connector